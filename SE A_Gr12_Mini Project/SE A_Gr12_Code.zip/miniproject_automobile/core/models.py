from django.db import models
from django.contrib.auth.models import User
from django.db.models import Sum


class Branch(models.Model):
    name = models.CharField(max_length=100)
    location = models.CharField(max_length=200)
    phone = models.CharField(max_length=20, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "Branches"
        ordering = ['name']

    def __str__(self):
        return f"{self.name} - {self.location}"

    def total_sales_amount(self):
        return self.sale_set.filter(status='COMPLETED').aggregate(
            total=Sum('total_price')
        )['total'] or 0

    def total_sales_count(self):
        return self.sale_set.filter(status='COMPLETED').count()

    def employee_count(self):
        return self.profile_set.filter(role='EMPLOYEE').count()


class Profile(models.Model):
    ROLE_CHOICES = [
        ('ADMIN', 'Admin'),
        ('MANAGER', 'Manager'),
        ('EMPLOYEE', 'Employee'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='EMPLOYEE')
    branch = models.ForeignKey(Branch, on_delete=models.SET_NULL, null=True, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    hire_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.get_full_name() or self.user.username} ({self.role})"

    def total_sales_amount(self):
        return self.user.sale_set.filter(status='COMPLETED').aggregate(
            total=Sum('total_price')
        )['total'] or 0

    def total_sales_count(self):
        return self.user.sale_set.filter(status='COMPLETED').count()


class Vehicle(models.Model):
    FUEL_CHOICES = [
        ('PETROL', 'Petrol'),
        ('DIESEL', 'Diesel'),
        ('ELECTRIC', 'Electric'),
        ('HYBRID', 'Hybrid'),
    ]
    STATUS_CHOICES = [
        ('AVAILABLE', 'Available'),
        ('SOLD', 'Sold'),
        ('RESERVED', 'Reserved'),
    ]

    make = models.CharField(max_length=50)
    model = models.CharField(max_length=50)
    year = models.PositiveIntegerField()
    color = models.CharField(max_length=30)
    vin = models.CharField(max_length=50, unique=True, verbose_name="VIN")
    fuel_type = models.CharField(max_length=20, choices=FUEL_CHOICES)
    price = models.DecimalField(max_digits=12, decimal_places=2)
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='AVAILABLE')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.year} {self.make} {self.model} ({self.vin})"


class Sale(models.Model):
    STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('COMPLETED', 'Completed'),
        ('CANCELLED', 'Cancelled'),
    ]

    vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE)
    salesperson = models.ForeignKey(User, on_delete=models.CASCADE)
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE)
    customer_name = models.CharField(max_length=100)
    customer_phone = models.CharField(max_length=20)
    customer_email = models.EmailField(blank=True)
    total_price = models.DecimalField(max_digits=12, decimal_places=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')
    sale_date = models.DateField(auto_now_add=True)
    notes = models.TextField(blank=True)

    def __str__(self):
        return f"Sale #{self.pk} - {self.vehicle} to {self.customer_name}"


class Target(models.Model):
    PERIOD_CHOICES = [
        ('MONTHLY', 'Monthly'),
        ('QUARTERLY', 'Quarterly'),
        ('YEARLY', 'Yearly'),
    ]

    employee = models.ForeignKey(User, on_delete=models.CASCADE)
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE)
    target_amount = models.DecimalField(max_digits=12, decimal_places=2)
    target_units = models.PositiveIntegerField(default=0)
    period = models.CharField(max_length=20, choices=PERIOD_CHOICES, default='MONTHLY')
    start_date = models.DateField()
    end_date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Target for {self.employee.get_full_name()} - {self.period}"

    def achieved_amount(self):
        return Sale.objects.filter(
            salesperson=self.employee,
            status='COMPLETED',
            sale_date__gte=self.start_date,
            sale_date__lte=self.end_date
        ).aggregate(total=Sum('total_price'))['total'] or 0

    def achieved_units(self):
        return Sale.objects.filter(
            salesperson=self.employee,
            status='COMPLETED',
            sale_date__gte=self.start_date,
            sale_date__lte=self.end_date
        ).count()

    def progress_percentage(self):
        if self.target_amount > 0:
            return round((self.achieved_amount() / self.target_amount) * 100, 1)
        return 0


class Incentive(models.Model):
    employee = models.ForeignKey(User, on_delete=models.CASCADE)
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    reason = models.CharField(max_length=200)
    date_awarded = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"Incentive: {self.employee.get_full_name()} - ${self.amount}"