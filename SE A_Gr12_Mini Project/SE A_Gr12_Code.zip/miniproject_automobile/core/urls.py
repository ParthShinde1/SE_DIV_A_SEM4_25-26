from django.urls import path
from . import views

urlpatterns = [
    # Auth
    path('', views.login_view, name='login'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard_router, name='dashboard_router'),

    # Admin Dashboard
    path('admin-panel/', views.admin_dashboard, name='admin_dashboard'),

    # Admin: Branches
    path('admin-panel/branches/', views.branch_list, name='branch_list'),
    path('admin-panel/branches/add/', views.branch_create, name='branch_create'),
    path('admin-panel/branches/<int:pk>/edit/', views.branch_edit, name='branch_edit'),
    path('admin-panel/branches/<int:pk>/delete/', views.branch_delete, name='branch_delete'),
    path('admin-panel/branches/compare/', views.branch_compare, name='branch_compare'),
    path('admin/branch-comparison/',views.branch_comparison,name='branch_comparison'),

    # Admin: Employees
    path('admin-panel/employees/', views.employee_list, name='employee_list'),
    path('admin-panel/employees/add/', views.employee_create, name='employee_create'),
    path('admin-panel/employees/<int:pk>/delete/', views.employee_delete, name='employee_delete'),

    # Admin: Vehicles
    path('admin-panel/vehicles/', views.vehicle_list, name='vehicle_list'),
    path('admin-panel/vehicles/add/', views.vehicle_create, name='vehicle_create'),
    path('admin-panel/vehicles/<int:pk>/edit/', views.vehicle_edit, name='vehicle_edit'),
    path('admin-panel/vehicles/<int:pk>/delete/', views.vehicle_delete, name='vehicle_delete'),

    # Admin: Sales
    path('admin-panel/sales/', views.admin_sales_list, name='admin_sales_list'),
    path('admin-panel/sales/<int:pk>/edit/', views.admin_sale_edit, name='admin_sale_edit'),
    path('admin/employee-performance/', views.admin_employee_performance_overview, name='admin_employee_performance_overview'),

    # Manager
    path('manager/', views.manager_dashboard, name='manager_dashboard'),
    path('manager/assign-target/', views.manager_assign_target, name='manager_assign_target'),
    path('manager/add-incentive/', views.manager_add_incentive, name='manager_add_incentive'),
    # path('manager/vehicles/', views.manager_vehicles, name='manager_vehicles'),  # TODO: Implement view

    # Employee
    path('employee/', views.employee_dashboard, name='employee_dashboard'),
    path('employee/add-sale/', views.employee_add_sale, name='employee_add_sale'),
    path('employee/sales-history/', views.employee_sales_history, name='employee_sales_history'),
    path('employee/sale/<int:pk>/edit/', views.employee_edit_sale, name='employee_edit_sale'),
    path('employee/<int:user_id>/performance/', views.employee_performance, name='employee_performance'),
]
