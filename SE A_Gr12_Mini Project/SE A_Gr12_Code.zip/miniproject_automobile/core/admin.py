from django.contrib import admin
from .models import Branch, Profile, Vehicle, Sale, Target, Incentive


@admin.register(Branch)
class BranchAdmin(admin.ModelAdmin):
    list_display = ['name', 'location', 'phone', 'created_at']


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'role', 'branch', 'phone']
    list_filter = ['role', 'branch']


@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display = ['make', 'model', 'year', 'vin', 'price', 'branch', 'status']
    list_filter = ['status', 'fuel_type', 'branch']


@admin.register(Sale)
class SaleAdmin(admin.ModelAdmin):
    list_display = ['id', 'vehicle', 'salesperson', 'customer_name', 'total_price', 'status', 'sale_date']
    list_filter = ['status', 'branch']


@admin.register(Target)
class TargetAdmin(admin.ModelAdmin):
    list_display = ['employee', 'branch', 'target_amount', 'period', 'start_date', 'end_date']
    list_filter = ['period', 'branch']


@admin.register(Incentive)
class IncentiveAdmin(admin.ModelAdmin):
    list_display = ['employee', 'branch', 'amount', 'reason', 'date_awarded']