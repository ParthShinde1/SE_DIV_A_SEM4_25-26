from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.db.models import Sum, Count, Q
import django.db.models as models

from .models import Branch, Profile, Vehicle, Sale, Target, Incentive
from .forms import (
    LoginForm, BranchForm, VehicleForm, EmployeeCreateForm,
    SaleForm, SaleUpdateForm, TargetForm, IncentiveForm
)
from .decorators import role_required


# ───────── AUTHENTICATION ─────────

def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard_router')

    form = LoginForm()

    if request.method == 'POST':
        form = LoginForm(request.POST)

        if form.is_valid():
            user = authenticate(
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password']
            )

            if user:
                login(request, user)
                return redirect('dashboard_router')
            else:
                messages.error(request, 'Invalid username or password')

    return render(request, 'core/login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('login')


@login_required
def dashboard_router(request):

    role = request.user.profile.role

    if role == 'ADMIN':
        return redirect('admin_dashboard')

    elif role == 'MANAGER':
        return redirect('manager_dashboard')

    else:
        return redirect('employee_dashboard')


# ───────── ADMIN DASHBOARD ─────────

@login_required
@role_required('ADMIN')
def admin_dashboard(request):

    context = {
        'total_branches': Branch.objects.count(),

        'total_employees': Profile.objects.exclude(role='ADMIN').count(),

        'total_vehicles': Vehicle.objects.count(),

        'available_vehicles': Vehicle.objects.filter(status='AVAILABLE').count(),

        'total_sales': Sale.objects.filter(status='COMPLETED').count(),

        'total_revenue': Sale.objects.filter(status='COMPLETED').aggregate(
            total=Sum('total_price')
        )['total'] or 0,

        'recent_sales': Sale.objects.select_related(
            'vehicle', 'salesperson', 'branch'
        ).order_by('-sale_date')[:10],

        'branches': Branch.objects.all(),
    }

    return render(request, 'core/admin/dashboard.html', context)


# ───────── BRANCH MANAGEMENT ─────────

@login_required
@role_required('ADMIN')
def branch_list(request):

    branches = Branch.objects.all()

    return render(request, 'core/admin/branch_list.html', {'branches': branches})


@login_required
@role_required('ADMIN')
def branch_create(request):

    form = BranchForm()

    if request.method == 'POST':

        form = BranchForm(request.POST)

        if form.is_valid():
            form.save()
            messages.success(request, 'Branch created successfully')
            return redirect('branch_list')

    return render(request, 'core/admin/branch_form.html', {
        'form': form,
        'title': 'Add Branch'
    })


@login_required
@role_required('ADMIN')
def branch_edit(request, pk):

    branch = get_object_or_404(Branch, pk=pk)

    form = BranchForm(instance=branch)

    if request.method == 'POST':

        form = BranchForm(request.POST, instance=branch)

        if form.is_valid():
            form.save()
            messages.success(request, 'Branch updated successfully')
            return redirect('branch_list')

    return render(request, 'core/admin/branch_form.html', {
        'form': form,
        'title': 'Edit Branch'
    })


@login_required
@role_required('ADMIN')
def branch_comparison(request):

    branches = Branch.objects.all()

    branch_data = Sale.objects.filter(
        status='COMPLETED'
    ).values(
        'branch__name'
    ).annotate(
        revenue=Sum('total_price'),
        sales=Count('id')
    )

    labels = [b['branch__name'] for b in branch_data]
    revenue_data = [float(b['revenue']) for b in branch_data]
    sales_data = [b['sales'] for b in branch_data]

    context = {
        "labels": labels,
        "revenue_data": revenue_data,
        "sales_data": sales_data
    }

    return render(request, "core/admin/branch_comparison.html", context)


@login_required
@role_required('ADMIN')
def branch_compare(request):
    if request.method == 'POST':
        branch1_id = request.POST.get('branch1')
        branch2_id = request.POST.get('branch2')
        
        try:
            branch1 = Branch.objects.get(pk=branch1_id)
            branch2 = Branch.objects.get(pk=branch2_id)
            
            # Branch 1 stats
            sales1 = Sale.objects.filter(branch=branch1, status='COMPLETED')
            revenue1 = sales1.aggregate(total=Sum('total_price'))['total'] or 0
            sales_count1 = sales1.count()
            recent_sales1 = sales1.order_by('-sale_date')[:5]
            
            # Branch 2 stats
            sales2 = Sale.objects.filter(branch=branch2, status='COMPLETED')
            revenue2 = sales2.aggregate(total=Sum('total_price'))['total'] or 0
            sales_count2 = sales2.count()
            recent_sales2 = sales2.order_by('-sale_date')[:5]
            
            # Calculate differences for template
            sales_diff = sales_count1 - sales_count2
            revenue_diff = revenue1 - revenue2
            
            context = {
                'branch1': branch1,
                'branch2': branch2,
                'revenue1': revenue1,
                'revenue2': revenue2,
                'sales_count1': sales_count1,
                'sales_count2': sales_count2,
                'sales_diff': sales_diff,
                'revenue_diff': revenue_diff,
                'recent_sales1': recent_sales1,
                'recent_sales2': recent_sales2,
                'revenue_data': [float(revenue1), float(revenue2)],
                'sales_data': [sales_count1, sales_count2],
                'labels': [branch1.name, branch2.name],
            }
            return render(request, 'core/admin/branch_comparison_detail.html', context)
            
        except Branch.DoesNotExist:
            messages.error(request, 'Invalid branch selection.')
            return redirect('branch_list')
    
    return redirect('branch_list')


@login_required
@role_required('ADMIN')
def branch_delete(request, pk):

    branch = get_object_or_404(Branch, pk=pk)

    if request.method == 'POST':
        branch.delete()
        messages.success(request, 'Branch deleted successfully')
        return redirect('branch_list')

    return render(request, 'core/admin/branch_confirm_delete.html', {
        'branch': branch
    })

@login_required
@role_required('MANAGER')
def manager_assign_target(request):

    branch = request.user.profile.branch

    form = TargetForm(branch=branch)

    if request.method == 'POST':
        form = TargetForm(request.POST, branch=branch)

        if form.is_valid():
            target = form.save(commit=False)
            target.branch = branch
            target.save()

            messages.success(request, 'Target assigned successfully')

            return redirect('manager_dashboard')

    return render(request, 'core/manager/target_form.html', {'form': form})


@login_required
@role_required('MANAGER')
def manager_add_incentive(request):

    branch = request.user.profile.branch

    form = IncentiveForm(branch=branch)

    if request.method == 'POST':

        form = IncentiveForm(request.POST, branch=branch)

        if form.is_valid():

            incentive = form.save(commit=False)
            incentive.branch = branch
            incentive.save()

            messages.success(request, 'Incentive awarded successfully')

            return redirect('manager_dashboard')

    return render(request, 'core/manager/incentive_form.html', {'form': form})


# ───────── EMPLOYEE MANAGEMENT ─────────

@login_required
@role_required('ADMIN')
def employee_list(request):

    employees = Profile.objects.select_related(
        'user', 'branch'
    ).exclude(role='ADMIN')

    # Override for managers to show branch totals
    for emp in employees:
        if emp.role == 'MANAGER' and emp.branch:
            emp.total_sales_count = emp.branch.total_sales_count()
            emp.total_sales_amount = emp.branch.total_sales_amount()
        else:
            emp.total_sales_count = emp.total_sales_count()
            emp.total_sales_amount = emp.total_sales_amount()

    employee_performers = [e for e in employees if e.role == 'EMPLOYEE']
    top_5_employees = sorted(employee_performers, key=lambda e: e.total_sales_amount or 0, reverse=True)[:5]
    
    return render(request, 'core/admin/employee_list.html', {
        'employees': employees,
        'top_5_employees': top_5_employees
    })


@login_required
@role_required('ADMIN')
def employee_create(request):

    form = EmployeeCreateForm()

    if request.method == 'POST':

        form = EmployeeCreateForm(request.POST)

        if form.is_valid():

            user = User.objects.create_user(
                username=form.cleaned_data['username'],
                email=form.cleaned_data['email'],
                password=form.cleaned_data['password'],
                first_name=form.cleaned_data['first_name'],
                last_name=form.cleaned_data['last_name']
            )

            user.profile.role = form.cleaned_data['role']
            user.profile.branch = form.cleaned_data['branch']
            user.profile.phone = form.cleaned_data['phone']

            user.profile.save()

            messages.success(request, 'Employee created successfully')

            return redirect('employee_list')

    return render(request, 'core/admin/employee_form.html', {
        'form': form,
        'title': 'Add Employee'
    })


@login_required
@role_required('ADMIN')
def employee_delete(request, pk):

    profile = get_object_or_404(Profile, pk=pk)

    if request.method == 'POST':

        profile.user.delete()

        messages.success(request, 'Employee deleted successfully')

        return redirect('employee_list')

    return render(request, 'core/admin/employee_confirm_delete.html', {
        'profile': profile
    })


# ───────── VEHICLE MANAGEMENT ─────────

@login_required
@role_required('ADMIN')
def vehicle_list(request):

    vehicles = Vehicle.objects.select_related('branch').all()

    return render(request, 'core/admin/vehicle_list.html', {
        'vehicles': vehicles
    })


@login_required
@role_required('ADMIN')
def vehicle_create(request):

    form = VehicleForm()

    if request.method == 'POST':

        form = VehicleForm(request.POST)

        if form.is_valid():
            form.save()
            messages.success(request, 'Vehicle added successfully')
            return redirect('vehicle_list')

    return render(request, 'core/admin/vehicle_form.html', {
        'form': form,
        'title': 'Add Vehicle'
    })


@login_required
@role_required('ADMIN')
def vehicle_edit(request, pk):

    vehicle = get_object_or_404(Vehicle, pk=pk)

    form = VehicleForm(instance=vehicle)

    if request.method == 'POST':

        form = VehicleForm(request.POST, instance=vehicle)

        if form.is_valid():
            form.save()
            messages.success(request, 'Vehicle updated successfully')
            return redirect('vehicle_list')

    return render(request, 'core/admin/vehicle_form.html', {
        'form': form,
        'title': 'Edit Vehicle'
    })


@login_required
@role_required('ADMIN')
def vehicle_delete(request, pk):

    vehicle = get_object_or_404(Vehicle, pk=pk)

    if request.method == 'POST':
        vehicle.delete()
        messages.success(request, 'Vehicle deleted successfully')
        return redirect('vehicle_list')

    return render(request, 'core/admin/vehicle_confirm_delete.html', {
        'vehicle': vehicle
    })


# ───────── ADMIN SALES ─────────

@login_required
@role_required('ADMIN')
def admin_sales_list(request):
    sales = Sale.objects.select_related(
        'vehicle', 'salesperson', 'branch'
    ).order_by('-sale_date')
    return render(request, 'core/admin/sales_list.html', {'sales': sales})


@login_required
@role_required('ADMIN')
def admin_sale_edit(request, pk):
    sale = get_object_or_404(Sale, pk=pk)
    form = SaleUpdateForm(instance=sale)
    if request.method == 'POST':
        form = SaleUpdateForm(request.POST, instance=sale)
        if form.is_valid():
            form.save()
            messages.success(request, 'Sale updated successfully')
            return redirect('admin_sales_list')
    return render(request, 'core/admin/sale_form.html', {
        'form': form,
        'sale': sale,
        'title': f'Edit Sale #{sale.pk}'
    })


# ───────── EMPLOYEE PERFORMANCE (ADMIN VIEW) ─────────

@login_required
@role_required('ADMIN')
def employee_performance(request, user_id):
    employee = get_object_or_404(User, id=user_id)
    profile = employee.profile

    is_manager = profile.role == 'MANAGER' and profile.branch is not None
    branch_sales = None
    total_sales = 0
    total_revenue = 0
    vehicles = []
    labels = []
    data = []

    if is_manager:
        # Branch totals for manager
        branch_sales = Sale.objects.filter(
            branch=profile.branch,
            status='COMPLETED'
        )
        total_sales = branch_sales.count()
        total_revenue = branch_sales.aggregate(
            total=Sum('total_price')
        )['total'] or 0
        vehicles = branch_sales.values('vehicle__model').annotate(
            total=Sum('total_price')
        )
    else:
        # Personal for employee
        personal_sales = Sale.objects.filter(
            salesperson=employee,
            status='COMPLETED'
        )
        total_sales = personal_sales.count()
        total_revenue = personal_sales.aggregate(
            total=Sum('total_price')
        )['total'] or 0
        vehicles = personal_sales.values('vehicle__model').annotate(
            total=Sum('total_price')
        )

    labels = [v['vehicle__model'] for v in vehicles]
    data = [float(v['total']) for v in vehicles]

    context = {
        "employee": employee,
        "profile": profile,
        "is_manager": is_manager,
        "branch_name": profile.branch.name if is_manager else None,
        "total_sales": total_sales,
        "total_revenue": total_revenue,
        "labels": labels,
        "data": data
    }

    return render(request, "core/admin/employee_performance.html", context)


# ───────── EMPLOYEE PERFORMANCE OVERVIEW (ADMIN) ─────────
from django.utils import timezone
from datetime import timedelta

@login_required
@role_required('ADMIN')
def admin_employee_performance_overview(request):
    employees = Profile.objects.select_related('user', 'branch').exclude(role__in=['ADMIN', 'MANAGER'])
    
    # Prepare aggregations like employee_list view
    for emp in employees:
        if emp.role == 'MANAGER' and emp.branch:
            emp.total_sales_count = emp.branch.total_sales_count()
            emp.total_sales_amount = emp.branch.total_sales_amount()
        else:
            emp.total_sales_count = emp.total_sales_count()
            emp.total_sales_amount = emp.total_sales_amount()
    
    # Sort by revenue (primary metric)
    sorted_employees = sorted(employees, key=lambda e: e.total_sales_amount or 0, reverse=True)
    
    top_employees = sorted_employees[:30]
    top_5_employees = sorted_employees[:5]
    
    # Top 10 for charts
    top10_sales_names = [emp.user.get_full_name()[:12] + '...' if len(emp.user.get_full_name()) > 12 else emp.user.get_full_name() for emp in sorted_employees[:10]]
    top10_sales_counts = [emp.total_sales_count or 0 for emp in sorted_employees[:10]]
    
    top10_revenue_names = top10_sales_names  # Same ordering
    top10_revenue_amounts = [float((emp.total_sales_amount or 0)/1000) for emp in sorted_employees[:10]]  # Thousands for 2150K display
    
    context = {
        'top_employees': top_employees,
        'top_5_employees': top_5_employees,
        'top10_sales_names': top10_sales_names,
        'top10_sales_counts': top10_sales_counts,
        'top10_revenue_names': top10_revenue_names,
        'top10_revenue_amounts': top10_revenue_amounts,
        'employees': sorted_employees,  # Fallback
        'total_employees': len(employees)
    }
    
    return render(request, 'core/admin/employee_performance_overview.html', context)


# ───────── MANAGER DASHBOARD ─────────

@login_required
@role_required('MANAGER')
def manager_dashboard(request):

    branch = request.user.profile.branch

    employees = Profile.objects.filter(
        branch=branch,
        role='EMPLOYEE'
    ).select_related('user')

    # Add targets and incentives for template
    targets = Target.objects.filter(branch=branch).select_related('employee')[:5]
    recent_incentives = Incentive.objects.filter(branch=branch).order_by('-date_awarded')[:5]

    context = {
        'branch': branch,
        'employees': employees,
        'total_employees': employees.count(),
        'branch_sales': Sale.objects.filter(
            branch=branch,
            status='COMPLETED'
        ).count(),
        'branch_revenue': Sale.objects.filter(
            branch=branch,
            status='COMPLETED'
        ).aggregate(total=Sum('total_price'))['total'] or 0,
        'available_vehicles': Vehicle.objects.filter(
            branch=branch,
            status='AVAILABLE'
        ).count(),
        'recent_sales': Sale.objects.filter(
            branch=branch
        ).select_related('vehicle', 'salesperson').order_by('-sale_date')[:10],
        'targets': targets,
        'recent_incentives': recent_incentives,
    }

    return render(request, 'core/manager/dashboard.html', context)


# ───────── EMPLOYEE DASHBOARD ─────────

@login_required
@role_required('EMPLOYEE')
def employee_dashboard(request):

    branch = request.user.profile.branch

    my_sales = Sale.objects.filter(
        salesperson=request.user
    ).select_related('vehicle').order_by('-sale_date')

    my_targets = Target.objects.filter(
        employee=request.user
    ).order_by('-start_date')

    my_incentives = Incentive.objects.filter(
        employee=request.user
    ).order_by('-date_awarded')

    vehicle_sales = my_sales.filter(
        status='COMPLETED'
    ).values('vehicle__model').annotate(
        total=Sum('total_price')
    )

    chart_labels = [v['vehicle__model'] for v in vehicle_sales]
    chart_data = [float(v['total']) for v in vehicle_sales]

    context = {
        'branch': branch,
        'my_sales': my_sales[:10],
        'total_sales': my_sales.filter(
            status='COMPLETED'
        ).count(),
        'total_revenue': my_sales.filter(
            status='COMPLETED'
        ).aggregate(total=Sum('total_price'))['total'] or 0,
        'my_targets': my_targets[:5],
        'my_incentives': my_incentives[:5],
        'total_incentives': my_incentives.aggregate(
            total=Sum('amount')
        )['total'] or 0,
        'chart_labels': chart_labels,
        'chart_data': chart_data
    }

    return render(request, 'core/employee/dashboard.html', context)


# ───────── EMPLOYEE ADD SALE ─────────

@login_required
@role_required('EMPLOYEE')
def employee_add_sale(request):

    branch = request.user.profile.branch

    form = SaleForm(branch=branch)

    if request.method == 'POST':

        form = SaleForm(request.POST, branch=branch)

        if form.is_valid():

            sale = form.save(commit=False)

            sale.salesperson = request.user
            sale.branch = branch

            sale.save()

            if sale.status == 'COMPLETED':
                vehicle = sale.vehicle
                vehicle.status = 'SOLD'
                vehicle.save()

            messages.success(request, 'Sale recorded successfully')

            return redirect('employee_dashboard')

    return render(request, 'core/employee/sale_form.html', {'form': form})


# ───────── EMPLOYEE SALES HISTORY ─────────

@login_required
@role_required('EMPLOYEE')
def employee_sales_history(request):

    sales = Sale.objects.filter(
        salesperson=request.user
    ).select_related('vehicle').order_by('-sale_date')

    return render(request, 'core/employee/sales_history.html', {
        'sales': sales
    })


# ───────── EMPLOYEE EDIT SALE ─────────

@login_required
@role_required('EMPLOYEE')
def employee_edit_sale(request, pk):
    sale = get_object_or_404(Sale, pk=pk, salesperson=request.user)
    form = SaleUpdateForm(instance=sale)
    if request.method == 'POST':
        form = SaleUpdateForm(request.POST, instance=sale)
        if form.is_valid():
            form.save()
            messages.success(request, 'Sale updated successfully')
            return redirect('employee_sales_history')
    return render(request, 'core/employee/sale_form.html', {
        'form': form,
        'sale': sale,
        'title': f'Edit Sale #{sale.pk}',
    })

